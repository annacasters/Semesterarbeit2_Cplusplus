#include "MovingShape.h"
#include <QPainter>
#include <QDebug>


//Constructor
//Startparameter: Startpunkt des Objekts, Sprungweite, Größe und Form des Objekts
MovingShape::MovingShape(QWidget *parent) : QWidget(parent) {
    setPointX(450);
    setPointY(550);
    setStep(50);
    setRectangleWidth(100);
    setRectangleHeight(100);
    setFocusPolicy(Qt::StrongFocus); //damit wird Funktion (Bewegen des Objekts) ausgeführt
}


//Bewegung der Tasten:
//Ausführung der Eingabe (Get und Set)
void MovingShape::move(IMovable::Direction richtung) { //richtung ist der Zustand
    switch (richtung) {
    case kDirectionLeft: //Taste Links
        setPointX(getPointX() - getStep());
        qDebug() << "Left";
        QWidget::update();
        break;
    case kDirectionRight: //Taste Rechts
        setPointX(getPointX() + getStep());
        qDebug() << "Right";
        QWidget::update();
        break;
    default:
        break;
    }
}

//Paintevent für Spieler
void MovingShape::paintEvent(QPaintEvent *event) {
    Q_UNUSED(event);
    QPainter painter;
    QRectF rectangle(getPointX(), getPointY(), getRectangleWidth(), getRectangleHeight());

    painter.begin(this);
    QColor PlayerRectangle ("#0000FF");
    Qt::BrushStyle StylePlayerRectangle = Qt::BDiagPattern;
    QBrush brushPlayerRectangle (PlayerRectangle, StylePlayerRectangle);
    painter.setBrush(brushPlayerRectangle);
    painter.setPen(QPen(Qt::red, 3));
    painter.drawRect(rectangle);
    painter.end();
}


//Bewegung: Eingabe der Tasten
void MovingShape::keyPressEvent(QKeyEvent *keyEvent)
{
    switch (keyEvent->key()) {
    case Qt::Key_Left:
        if (_pointX > 0) //Verhindert, dass der Spieler rechts über den Widgetrand hinaus kann
        move(kDirectionLeft);
        break;
    case Qt::Key_Right:
        if (_pointX + 100 < 1000) //Verhindert, dass der Spieler links über den Widgetrand hinaus kann
        move(kDirectionRight);
        break;
    default:
        break;
    }
}


// Get & Set
// Definition Get (neuer X bzw Y-Wert) und Set (alten X bzw Y-Wert mit Neuem austauschen)

//Get X- und Y-Wert
int MovingShape::getPointX() const
{
    return _pointX;
}
int MovingShape::getPointY() const
{
    return _pointY;
}
//Set X- und Y-Wert
void MovingShape::setPointX(int pointX)
{
    _pointX = pointX;
}
void MovingShape::setPointY(int pointY)
{
    _pointY = pointY;
}

//Get Bewegung
int MovingShape::getStep() const
{
    return _step;
}
//Set Bewegung
void MovingShape::setStep(int step)
{
    _step = step;
}

//Get Höhe und Breite
int MovingShape::getRectangleHeight() const
{
    return _rectangleHeight;
}
int MovingShape::getRectangleWidth() const
{
    return _rectangleWidth;
}
//Set Höhe und Breite
void MovingShape::setRectangleHeight(int rectangleHeight)
{
    _rectangleHeight = rectangleHeight;
}
void MovingShape::setRectangleWidth(int rectangleWidth)
{
    _rectangleWidth = rectangleWidth;
}
