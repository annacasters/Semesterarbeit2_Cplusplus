#ifndef MOVING_SHAPE_1_MAINWINDOW_H
#define MOVING_SHAPE_1_MAINWINDOW_H

#include <QMainWindow>
#include <QFile>
#include <QTimer>
#include "MovingShape.h"

class MovingShape;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:

    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow(); //Dekonstruktor

    void serialize(QFile &file);
    void deserialize(QFile &file);

    void start(void) { timer->start(10); increment1=1; increment2=1; increment3=1; increment4=1;};
    void stop(void) { timer->stop(); increment1=0; increment2=0; increment3=0; increment4=0;};

private:
    Ui::MainWindow *ui;
    MovingShape *_shape;

    int points;

    QTimer *timer;
    int ys1, ys2, ys3;
    int xs1, xs2, xs3;
    int x1; int x2; int x3;
    int y1, y2, y3;
    int increment1, increment2,increment3, increment4;
    int phase1;
    int phase2;
    int phase3;
    int playerX;

protected:
     void paintEvent(QPaintEvent *event);
};
#endif // MOVING_SHAPE_1_MAINWINDOW_H
