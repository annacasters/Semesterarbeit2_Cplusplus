#include <QtGui>
#include <QApplication>
#include <QPushButton>
#include <QGridLayout>
#include <QTimer>
#include <QDebug>

#include "meinwidget.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "MovingShape.h"


//Constructor
MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    setPalette(QPalette(QColor(92, 92, 92)));//Hintergrundfarbe des Spielfelds
    setAutoFillBackground(true);
    setMouseTracking(false);

    //Spieler (Viereck)
    ui->setupUi(this);
    _shape = new MovingShape(this);
    setCentralWidget(_shape);
    setWindowTitle("Annas Super-Game");

    //Timer für fallende Objekte
    timer=new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(update()));


    //String points auf Startwert 0 setzen
    points=0;

    //Start- und Stoppfunktion
    increment1=0;
    increment2=0;
    increment3=0;
    increment4=0;
    //Zustände der 3 fallenden Objekte
    phase1=0;
    phase2=0;
    phase3=0;

    //X und Y Startwerte der fallenden Objekte werden festgesetzt
    y1 = -80;
    y2 = -80;
    y3 = -80;
    x1 = 290;
    x2 = 490;
    x3 = 690;
}
//Deconstructor
MainWindow::~MainWindow() {
}

//Paintevent für Lebensanzeige, Punktezähler und fallende Objekte
void MainWindow::paintEvent(QPaintEvent * ){
    QPainter painter, painter1, painter2, painter3, painter4, painter5;

    int ys1, ys2, ys3;
    int xs1, xs2, xs3;

    //Startwerte werden in neuem Integer zwischengespeichert, da die X und Y Werte veränderbar sein sollen
    ys1 = y1;
    ys2 = y2;
    ys3 = y3;
    xs1 = x1;
    xs2 = x2;
    xs3 = x3;

   painter.begin(this); //startet den ersten Painter

//Ellipsen als Lebensanzeige(rechts oben)
    QColor Ellipse0("#FF3030"); //RGB Code Rot
    Qt::BrushStyle styleEllipse0 = Qt::SolidPattern;
    QBrush brushEllipse0(Ellipse0, styleEllipse0);
    painter.setBrush(brushEllipse0); //Ellipse wird mit Farbe ausgefüllt
    painter.setPen(QPen(Qt::black, 3)); // 3px Schwarzer Rand
    painter.drawEllipse(940,20,50,50); //Painter wird aufgerufen bzw. ausgelöst; (XWert, YWert, Formangaben)

    QColor Ellipse1("#FF3030");
    Qt::BrushStyle styleEllipse1 = Qt::SolidPattern;
    QBrush brushEllipse1(Ellipse1, styleEllipse1);
    painter.setBrush(brushEllipse1);
    painter.setPen(QPen(Qt::black, 3));
    painter.drawEllipse(880,20,50,50);

    QColor Ellipse2("#FF3030");
    Qt::BrushStyle styleEllipse2 = Qt::SolidPattern;
    QBrush brushEllipse2(Ellipse2, styleEllipse2);
    painter.setBrush(brushEllipse2);
    painter.setPen(QPen(Qt::black, 3));
    painter.drawEllipse(820,20,50,50);

//fallende Objekte (Gegner)
    painter1.begin(this); //Painter für 1 Gegner wird aufgerufen
    QColor Rect1 ("#000000"); //Schwarz
    Qt::BrushStyle styleRect1 = Qt::Dense1Pattern; //Muster
    QBrush brushRect1(Rect1,styleRect1);
    painter1.setPen(QPen(Qt::black, 3));
    painter1.setBrush(brushRect1);
    painter1.drawRect(xs1, ys1, 50, 50);

    //If Schleife für 1. fallendes Objekt; springt sobald wenn Bedingung nicht mehr zutrifft in else und somit dann in das nächste Case
    //durch 4 verschiedene Geschwindigkeiten scheint es so, als ob die Objekte von oben random runterfallen
    if (increment1)
        switch(phase1)
        {
        case 0:
            if (y1<=750) y1=y1+7; //wenn und solange Y kleiner gleich 750 ist, dann ändert sich der Y-Wert in 7er Schritten
            else phase1=1, y1 =-50; //Wenn Y größer als 750 ist, also der die Bedingung nicht mehr zutrifft, wird Y wieder auf -50 gesetzt und die if-Schleife springt...
            break;
        case 1: //springt in das nächste Case mit neuen Bedingungen
            if (y1<=750) x1=500, y1=y1+5;
            else phase1=2, y1=-50;
            break;
        case 2:
            if (y1<=750) x1=250, y1=y1+8;
            else phase1=3, y1=-50;
            break;
        case 3:
            if (y1<=750) x1=450, y1=y1+6.5;
            else phase1=0, y1=-50;
            break;
        };

    painter2.begin(this);
    QColor Rect2 ("#000000");
    Qt::BrushStyle styleRect2 = Qt::Dense1Pattern;
    QBrush brushRect2(Rect2,styleRect2);
    painter2.setPen(QPen(Qt::gray, 3));
    painter2.setBrush(brushRect2);
    painter2.drawRect(xs2, ys2, 50, 50);

    //If-Schleife für 2tes fallende Objekt
    if (increment2)
        switch(phase2)
        {
        case 0:
            if (y2<=750) y2=y2+7;
            else phase2=1, y2 =-50;
            break;
        case 1:
            if (y2<=750) x2=220 , y2=y2+9;
            else phase2=2, y2 =-50;
            break;
        case 2:
            if (y2<=750) x2=330, y2=y2+5;
            else phase2=3, y2 =-50;
            break;
        case 3:
            if (y2<=750) x2=440, y2=y2+7.5;
            else phase2=0, y2 =-50;
            break;
        };

    painter3.begin(this);
    QColor Rect3 ("#000000");
    Qt::BrushStyle styleRect3 = Qt::Dense1Pattern;
    QBrush brushRect3(Rect3,styleRect3);
    painter3.setPen(QPen(Qt::magenta, 3));
    painter3.setBrush(brushRect3);
    painter3.drawRect(xs3, ys3, 50, 50);

    //If-Schleife für drittes fallendes Objekt
    if (increment3)
        switch(phase3)
        {
        case 0:
            if (y3<=750) y3=y3+5;
            else phase3=1, y3 = -50;
            break;
        case 1:
            if (y3<=750) x3=110 , y3=y3+6;
            else phase3=2, y3 = -50;
            break;
        case 2:
            if (y3<=750) x3=315, y3=y3+9;
            else phase3=3, y3 = -50;
            break;
        case 3:
            if (y3<=750) x3=666, y3=y3+8;
            else phase3=0, y3 = -50;
            break;
        };

//Painter für Punktestand
    painter4.begin(this);
    painter4.setPen(Qt::white);
    painter4.setFont(QFont("Spring Holiday",30));
    painter4.drawText(20, 80, QString::number(points));//Text in String wird in Integer (Zahl) umgewandelt

    //Punktestandfunktion; Increment4 mit Start und Stoppbutton verknüpft;
    if(increment4){
        points++; //Mit ++ wird gleichmäßig hochgezählt
    };
    //qDebug() << "points"; --> damit lassen sich Werte im Debugger ausgeben

//Painter für Text
    painter5.begin(this);
    painter5.setFont(QFont("Impact",35));
    painter5.setPen(Qt::black);
    painter5.drawText(20, 40, tr("Punkte:"));

//Alle Painter werden beendet
    painter.end();
    painter1.end();
    painter2.end();
    painter3.end();
    painter4.end();
    painter5.end();
}

//Methode serialize
void MainWindow::serialize(QFile &file) {
    QTextStream out (&file);

    //hole die momentane X-Koordinate des Players (-shape), speichere sie in pX
    int pX = _shape->getPointX();
    //speichere pX in Datei
    out << pX << endl;
    out << points << endl;
    out << x1 << endl;
    out << x2 << endl;
    out << x3 << endl;
    out << y1 << endl;
    out << y2 << endl;
    out << y3 << endl;
    //Wert von x1, x2, x3 und y1, y2, y3 werden in Datei geschrieben
}

//Methode deserialize -> Inhalte eines menschlich-lesbaren Formats in machinen-lesbares Format
void MainWindow::deserialize(QFile &file) {
    QTextStream in(&file);
   int x1h, x2h, x3h; //Variabeln für Zwischenspeicher
   int y1h, y2h, y3h;
   int player;
   int pointsSpeicher;

   //Werte werden in Zwischenspeicher geschrieben
   //gleiche Reihenfolge wie in Serialize
   in >> player >> endl;
   in >> pointsSpeicher >> endl;
   in >> x1h >> endl;
   in >> x2h >> endl;
   in >> x3h >> endl;
   in >> y1h >> endl;
   in >> y2h >> endl;
   in >> y3h >> endl;

   playerX = player;
   _shape->setPointX(playerX);
   points = pointsSpeicher;
   x1 = x1h;
   x2 = x2h;
   x3 = x3h;
   y1 = y1h;
   y2 = y2h;
   y3 = y3h;

    update();

}


