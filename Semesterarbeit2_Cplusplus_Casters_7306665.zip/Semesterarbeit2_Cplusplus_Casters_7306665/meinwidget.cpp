#include <QtGui>
#include <QPushButton>
#include <QGridLayout>
#include <QFileDialog>
#include <QMessageBox>
#include <QTimer>

#include "meinwidget.h"
#include "mainwindow.h"


meinWidget::meinWidget(QWidget *parent) : QWidget(parent)
{
    //Button Spiel beenden
    QPushButton *quit = new QPushButton(tr("Ende"));
    quit->setFont(QFont("Times", 18, QFont::Bold));
    connect(quit, SIGNAL(clicked()), qApp, SLOT(quit()));

    //Button Spiel speichern
    QPushButton *speichern = new QPushButton(tr("speichern"));
    speichern->setFont(QFont("Times", 18, QFont::Bold));
    connect(speichern, SIGNAL(clicked()), this, SLOT(speichern()));
    //SLOT <-- click-SIGNAL wird auf die Methode speichern() übertragen

    //Button gespeichertes Spiel laden
    QPushButton *laden =new QPushButton(tr("Laden"));
    laden->setFont(QFont("Times", 18, QFont::Bold));
    connect(laden, SIGNAL(clicked()), this, SLOT(laden()));

    //Button Spiel starten (Counter und fallende Objekte)
    QPushButton *startButton = new QPushButton(tr("Start"));
    startButton->setFont(QFont("Times", 18, QFont::Bold));
    connect(startButton, SIGNAL(clicked()), this, SLOT(start()));

    //Button Spiel stoppen
    QPushButton *stopButton = new QPushButton(tr("Stop"));
    stopButton->setFont(QFont("Times", 18, QFont::Bold));
    connect(stopButton, SIGNAL(clicked()), this, SLOT(stop()));

    //Zeichenfeld (Spielfeld) wird festgesezt
    meinZeichenFeld = new MainWindow;
    meinZeichenFeld->setFixedSize(1000,700);

    //Anordnung der Buttons
    QGridLayout *gridLayout = new QGridLayout;
    gridLayout->addWidget(quit, 0, 0);
    gridLayout->addWidget(startButton, 1, 0);
    gridLayout->addWidget(stopButton, 2, 0);
    gridLayout->addWidget(speichern, 3, 0);
    gridLayout->addWidget(laden, 4, 0);
    gridLayout->addWidget(meinZeichenFeld, 0, 1, 6, 1);
    gridLayout->setColumnStretch(1, 10);
    setLayout(gridLayout);

}

void meinWidget::start(void){
    meinZeichenFeld->start(); //Verknüpfung Zeichenfeld mit Startfunktion
}

void meinWidget::stop(void){
    meinZeichenFeld->stop(); //Verknüpfung Zeichenfeld mit Stopfunktion
}

//Spiel speichern()
void meinWidget::speichern() {

    QFileDialog dialog(this);
        QString fileName;
        QFile file;

        dialog.setFileMode(QFileDialog::AnyFile);
        fileName = dialog.getSaveFileName(this,
                                          tr("Speichern als"), ".", tr("Zeichnungen (*.myz)"));

        if (fileName.isNull()==false)
        {
            file.setFileName(fileName);
            if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
            {
                QMessageBox::warning(this, tr("Dateifehler"),
                                     tr("Folgende Datei kann nicht verwendet werden: ") + fileName,QMessageBox::Ok);
            }

            meinZeichenFeld->serialize(file);
            //Zahlen in die Datei
            file.close();
            return;
        }
}

//gespeicherter Spielstand laden
void meinWidget::laden() {
    QFileDialog dialog(this);
        QString fileName;
        QFile file;

        dialog.setFileMode(QFileDialog::AnyFile);
        fileName = dialog.getOpenFileName(this,
                                          tr("Öffnen als"), ".", tr("Zeichnungen (*.myz)"));

        if (fileName.isNull()==false)
        {
            file.setFileName(fileName);
            if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
            {
                QMessageBox::warning(this, tr("Dateifehler"),
                                     tr("Folgende Datei kann nicht geÃ¶ffnet werden: ") + fileName,QMessageBox::Ok);
            }

            meinZeichenFeld->deserialize(file);
            file.close();
            return;
        }
}
