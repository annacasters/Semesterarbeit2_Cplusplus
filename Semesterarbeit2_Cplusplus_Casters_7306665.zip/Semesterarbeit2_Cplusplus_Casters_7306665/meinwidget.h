#ifndef MEINWIDGET_H
#define MEINWIDGET_H

#include <QWidget>
#include <mainwindow.h>
#include <MovingShape.h>

class meinWidget : public QWidget
{
    Q_OBJECT //Makro, Klasse enthält QT spezifische Anweisungen

    private:
    MainWindow *meinZeichenFeld;

    public:
    meinWidget(QWidget *parent = 0);

    public slots: //Methoden werden hier definiert, damit sie später mit dem Button (SLOT) verbunden werden können
    void speichern();
    void laden();
    void start(void);
    void stop(void);

};

#endif // MEINWIDGET_H
