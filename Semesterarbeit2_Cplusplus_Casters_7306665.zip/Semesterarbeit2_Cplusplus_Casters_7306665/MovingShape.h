#ifndef MOVING_SHAPE_1_MOVINGSHAPE_H_
#define MOVING_SHAPE_1_MOVINGSHAPE_H_

#include <QObject>
#include <QWidget>
#include <QKeyEvent>

// Auflistung der Fälle
class IMovable {
public:
    enum Direction {
        kDirectionRight,
        kDirectionLeft
    };

//virtual: dynamisch anstatt statisch (kann verändert werden)
public:
    virtual ~IMovable() {} //Dekonstruktor
    virtual void move(Direction) = 0;
};

class MovingShape : public QWidget, public IMovable
{
    Q_OBJECT
public:
    explicit MovingShape(QWidget *parent = 0);

    void move(Direction);

    int getPointX() const;
    int getPointY() const;
    void setPointX(int pointX);
    void setPointY(int pointY);
    int getStep() const;
    void setStep(int step);
    int getRectangleWidth() const;
    int getRectangleHeight() const;
    void setRectangleWidth(int ellipseWidth);
    void setRectangleHeight(int ellipseHeight);


protected:
    void keyPressEvent(QKeyEvent *keyEvent);
    void paintEvent(QPaintEvent *event);

private:
    int _pointX;
    int _pointY;
    int _step;
    int _rectangleWidth;
    int _rectangleHeight;

};

#endif // MOVING_SHAPE_1_MOVINGSHAPE_H
