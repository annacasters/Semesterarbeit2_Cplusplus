#include "mainwindow.h"
#include "meinwidget.h"
#include "MovingShape.h"

#include <QApplication>
#include <QTimer>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    meinWidget w;
    w.setGeometry(100, 100, 500, 355);
    w.show();

    return a.exec();
}
